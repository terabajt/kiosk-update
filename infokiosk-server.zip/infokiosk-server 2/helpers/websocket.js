//WEBSOCKET INIT
const https = require('https');
const fs = require('fs');
const WebSocket = require('ws');
const { config } = require('dotenv');

require('dotenv/config');

const PORT_WEBSOCKET = process.env.PORT_WEBSOCKET;

const server = https.createServer({
	cert: fs.readFileSync('./cert.pem'),
	key: fs.readFileSync('./key.pem'),
});

const wss = new WebSocket.Server({ server });

server.listen(`${PORT_WEBSOCKET}`, () => {
	console.log(`WebSocket server is running on port: ${PORT_WEBSOCKET}`);
});

const clients = [];
wss.on('connection', function connection(ws) {
	clients.push(ws);
	ws.on('message', function incoming(message) {
		console.log('received: %s', message);
	});
	ws.on('close', function close() {
		clients.splice(clients.indexOf(ws), 1);
	});
});

// WEBSOCKET  BROADCAST
function broadcastMessage(message) {
	clients.forEach(client => {
		if (client.readyState === WebSocket.OPEN) {
			client.send(message);
		}
	});
}

module.exports = broadcastMessage;
