const expressJwt = require('express-jwt');

function authJwt() {
	const secret = process.env.SECRET;
	const api = process.env.API_URL;

	return expressJwt({
		secret,
		algorithms: ['HS256'],
		// isRevoked: isRevoked,
	}).unless({
		path: [
			`${api}/users/login`,
			`${api}/users/register`,
			`${api}/images/upload`,
			/\/uploads\/*/, // images
			/\/activation\/*/,
			{ url: `${api}/infos`, methods: ['GET'] },
			{ url: `${api}/timetable`, methods: ['GET'] },
			{ url: `${api}/settings`, methods: ['GET'] },
			{ url: `${api}/categories`, methods: ['GET'] },
			{ url: `${api}/categoriesItem`, methods: ['GET'] },
			{ url: new RegExp(`${api}/infos/[^/]+$`), methods: ['GET'] },
			{ url: new RegExp(`${api}/timetable/[^/]+$`), methods: ['GET'] },
			{ url: new RegExp(`${api}/settings/[^/]+$`), methods: ['GET'] },
			{ url: new RegExp(`${api}/categories/[^/]+$`), methods: ['GET'] },
			{ url: new RegExp(`${api}/categoriesItem/[^/]+$`), methods: ['GET'] },
			// { url: /(.*)/ },
		],
	});
}

module.exports = authJwt;
