const express = require('express');
const { Timetable } = require('../models/timetable');
const { default: mongoose } = require('mongoose');
const multer = require('multer');

const router = express.Router();
const storage = multer.diskStorage({
	destination: function (req, file, cb) {
		cb(null, 'uploads/');
	},
	filename: function (req, file, cb) {
		const originalname = file.originalname;
		const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
		const extension = originalname.split('.').pop();
		cb(null, originalname + '-' + uniqueSuffix + '.' + extension);
	},
});

const upload = multer({
	storage: storage,
	limits: {
		fileSize: 1024 * 1024 * 10, // Przykładowy limit 10MB
	},
	fileFilter: (req, file, cb) => {
		if (file.mimetype === 'image/jpeg' || file.mimetype === 'image/png') {
			cb(null, true);
		} else {
			cb(new Error('Niedozwolony format pliku. Dozwolone formaty: JPEG i PNG'));
		}
	},
});

router.get('/', async (req, res) => {
	try {
		const timetablesList = await Timetable.find();
		res.send(timetablesList);
	} catch (error) {
		console.error(error);
		res.status(500).json({ message: 'Server Error' });
	}
});

router.get('/:id', async (req, res) => {
	try {
		const { id } = req.params;
		if (!mongoose.Types.ObjectId.isValid(id)) {
			return res.status(500).json({ message: 'InvalidID format.' });
		}
		const timetables = await Timetable.findById(req.params.id);
		if (!timetables) res.status(404).json({ message: 'Id not found.' });
		res.send(timetables);
	} catch (error) {
		res.status(500).json({ message: error });
	}
});

router.post('/', upload.fields([{ name: 'images' }]), async (req, res) => {
	try {
		const timetable = new Timetable({
			grade: req.body.grade,
			text_pl: req.body.text_pl,
			text_en: req.body.text_en,
			text_ua: req.body.text_ua,
			comments: req.body.comments,
			display: req.body.display,
		});

		const savedTimetable = await timetable.save();

		res.status(201).json('savedTimetable');
	} catch (error) {
		console.error(error);
		res.status(500).json({ message: 'Server Error' });
	}
});

router.delete('/:id', async (req, res) => {
	try {
		const { id } = req.params;
		if (!mongoose.Types.ObjectId.isValid(id)) {
			return res.status(500).json({ message: 'Invalid ID format.' });
		}
		const timetable = await Timetable.findByIdAndDelete(id);
		if (!timetable) {
			return res.status(404).json({ message: 'Timetable not found.' });
		}
		res.send(timetable);
	} catch (error) {
		res.status(500).json({ message: error.message });
	}
});

router.put('/:id', upload.fields([{ name: 'images' }]), async (req, res) => {
	try {
		const { id } = req.params;
		const timetable = await Timetable.findById(id);
		if (!timetable) {
			return res.status(404).json({ message: 'Timetable not found' });
		}
		timetable.grade = req.body.grade;
		timetable.text_pl = req.body.text_pl;
		timetable.text_en = req.body.text_en;
		timetable.text_ua = req.body.text_ua;
		timetable.comments = req.body.comments;
		timetable.display = req.body.display;
		const updatedTimetable = await timetable.save();

		res.status(200).json(updatedTimetable);
	} catch (error) {
		console.error(error);
		res.status(500).json({ message: 'Server Error' });
	}
});

module.exports = router;
