const express = require('express');
const { Info } = require('../models/info');
const multer = require('multer');
const { default: mongoose } = require('mongoose');

const router = express.Router();

const broadcastMessage = require('../helpers/websocket');
const { History } = require('../models/history');

const storage = multer.diskStorage({
	destination: function (req, file, cb) {
		cb(null, 'uploads/');
	},
	filename: function (req, file, cb) {
		const originalname = file.originalname;
		const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
		const extension = originalname.split('.').pop();
		cb(null, originalname + '-' + uniqueSuffix + '.' + extension); // Unique filename
	},
});

const upload = multer({
	storage: storage,
	limits: {
		fileSize: 20 * 1024 * 1024, // 20MB limit dla pojedynczego pliku
		fieldSize: 100 * 1024 * 1024, // Zwiększono limit na wielkość pola do 100MB
	},
	fileFilter: (req, file, cb) => {
		if (file.mimetype === 'image/jpeg' || file.mimetype === 'image/png') {
			cb(null, true);
		} else {
			cb(new Error('Niedozwolony format pliku. Dozwolone formaty: JPEG i PNG'));
		}
	},
});

router.get('/', async (req, res) => {
	try {
		const infosList = await Info.find().populate('category');
		res.send(infosList);
	} catch (error) {
		console.error(error);
		res.status(500).json({ message: 'Server Error' });
	}
});

router.get('/:id', async (req, res) => {
	try {
		const { id } = req.params;
		if (!mongoose.Types.ObjectId.isValid(id)) {
			return res.status(500).json({ message: 'InvalidID format.' });
		}
		const info = await Info.findById(req.params.id).populate('category');
		if (!info) res.status(404).json({ message: 'Id not found.' });
		res.send(info);
	} catch (error) {
		res.status(500).json({ message: error });
	}
});

router.post('/', upload.fields([{ name: 'images' }]), async (req, res) => {
	try {
		const imagePaths = Object.values(req.files).flatMap(files => files.map(file => file.path));
		const info = new Info({
			name: req.body.name,
			title_pl: req.body.title_pl,
			title_ua: req.body.title_ua,
			title_en: req.body.title_en,
			text_pl: req.body.text_pl,
			text_en: req.body.text_en,
			text_ua: req.body.text_ua,
			category: req.body.category,
			date: req.body.date,
			date_to_display: req.body.date_to_display,
			display: req.body.display,
			images: imagePaths,
		});

		const savedInfo = await info.save();
		const history = new History({
			editedBy: req.user.userId,
			infoId: savedInfo._id, // Retrieve infoId from the saved Info instance
		});
		const savedHistory = await history.save();
		console.log(history);
		broadcastMessage(JSON.stringify({ type: 'info', content: 'Dodano nowe informacje' }));
		res.status(201).json(savedInfo);
	} catch (error) {
		console.error(error);
		res.status(500).json({ message: 'Server Error' });
	}
});

router.put('/:id', upload.fields([{ name: 'images' }]), async (req, res) => {
	try {
		const { id } = req.params;
		const info = await Info.findById(id);
		if (!info) {
			return res.status(404).json({ message: 'Info not found' });
		}
		// Update the Info instance
		info.name = req.body.name;
		info.title_pl = req.body.title_pl;
		info.title_ua = req.body.title_ua;
		info.title_en = req.body.title_en;
		info.text_pl = req.body.text_pl;
		info.text_en = req.body.text_en;
		info.text_ua = req.body.text_ua;
		info.category = req.body.category;
		info.date = req.body.date;
		info.date_to_display = req.body.date_to_display;
		info.display = req.body.display;
		info.images = req.body.images;

		const updatedInfo = await info.save();
		const history = new History({
			editedBy: req.user.userId,
			infoId: updatedInfo._id, // Retrieve infoId from the updated Info instance
		});
		const savedHistory = await history.save();
		broadcastMessage(JSON.stringify({ type: 'info', content: 'Dodano nowe informacje' }));

		res.status(200).json(updatedInfo);
	} catch (error) {
		console.error(error);
		res.status(500).json({ message: 'Server Error' });
	}
});
router.delete('/:id', async (req, res) => {
	try {
		const { id } = req.params;

		if (!mongoose.Types.ObjectId.isValid(id)) {
			return res.status(500).json({ message: 'Invalid ID format.' });
		}

		// Delete the Info document
		const info = await Info.findByIdAndDelete(id);

		// Delete associated history records
		await History.deleteMany({ infoId: id });

		if (!info) {
			return res.status(404).json({ message: 'Info not found.' });
		}

		broadcastMessage(JSON.stringify({ type: 'info', content: 'Usunięto informacje' }));
		res.send(info);
	} catch (error) {
		res.status(500).json({ message: error.message });
	}
});

module.exports = router;
