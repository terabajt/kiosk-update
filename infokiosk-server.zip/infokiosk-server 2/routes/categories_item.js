const express = require('express');
const { CategoryItem } = require('../models/category_item');
const { default: mongoose } = require('mongoose');
const multer = require('multer');
const { Info } = require('../models/info');
const broadcastMessage = require('../helpers/websocket');

const router = express.Router();

const storage = multer.diskStorage({
	destination: function (req, file, cb) {
		cb(null, 'uploads/');
	},
	filename: function (req, file, cb) {
		const originalname = file.originalname;
		const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
		const extension = originalname.split('.').pop();
		cb(null, originalname + '-' + uniqueSuffix + '.' + extension);
	},
});

const upload = multer({
	storage: storage,
	limits: {
		fileSize: 1024 * 1024 * 10, // Przykładowy limit 10MB
	},
	fileFilter: (req, file, cb) => {
		if (file.mimetype === 'image/jpeg' || file.mimetype === 'image/png') {
			cb(null, true);
		} else {
			cb(new Error('Niedozwolony format pliku. Dozwolone formaty: JPEG i PNG'));
		}
	},
});

router.get('/', async (req, res) => {
	try {
		const categoriesList = await CategoryItem.find().populate('infoId');
		res.send(categoriesList);
	} catch (error) {
		console.error(error);
		res.status(500).json({ message: 'Server Error' });
	}
});

router.get('/:id', async (req, res) => {
	try {
		const { id } = req.params;
		if (!mongoose.Types.ObjectId.isValid(id)) {
			return res.status(500).json({ message: 'InvalidID format.' });
		}
		const category = await CategoryItem.findById(req.params.id);
		if (!category) res.status(404).json({ message: 'Id not found.' });
		res.send(category);
	} catch (error) {
		res.status(500).json({ message: error });
	}
});

router.post('/', upload.fields([{ name: 'images' }]), async (req, res) => {
	try {
		const category = new CategoryItem({
			label_pl: req.body.label_pl,
			label_en: req.body.label_en,
			label_ua: req.body.label_ua,
			icon: req.body.icon,
			routerLink: 'item/' + req.body.infoId,
			display: req.body.display,
			infoId: req.body.infoId,
		});
		const savedCategory = await category.save();
		broadcastMessage(JSON.stringify({ type: 'info', content: 'Dodano nową kategorię.' }));
		res.status(201).json(savedCategory);
	} catch (error) {
		console.error(error);
		res.status(500).json({ message: 'Server Error' });
	}
});

router.put('/:id', upload.fields([{ name: 'images' }]), async (req, res) => {
	try {
		const { id } = req.params;
		const category = await CategoryItem.findById(id);
		if (!category) {
			return res.status(404).json({ message: 'Category not found' });
		}
		(category.label_pl = req.body.label_pl),
			(category.label_en = req.body.label_en),
			(category.label_ua = req.body.label_ua),
			(category.icon = req.body.icon),
			(category.routerLink = req.body.routerLink),
			(category.display = req.body.display);
		category.infoId = req.body.infoId;

		const updatedCategory = await category.save();
		broadcastMessage(JSON.stringify({ type: 'info', content: 'Zaktualizowano kategorię.' }));

		res.status(200).json(updatedCategory);
	} catch (error) {
		console.error(error);
		res.status(500).json({ message: 'Server Error' });
	}
});
router.delete('/:id', async (req, res) => {
	try {
		const { id } = req.params;

		if (!mongoose.Types.ObjectId.isValid(id)) {
			return res.status(500).json({ message: 'Invalid ID format.' });
		}

		// Check if info exist with that category
		const categoryInfoCount = await Info.countDocuments({ category: id });

		if (categoryInfoCount > 0) {
			return res.status(400).json({
				message: 'Nie możesz usunąć tej kategorii, ponieważ są z nią powiązane wpisy. Najpierw usuń przypisane wpisy.',
			});
		}

		const category = await CategoryItem.findByIdAndDelete(id);
		broadcastMessage(JSON.stringify({ type: 'info', content: 'Usunięto kategorię.' }));

		if (!category) {
			return res.status(404).json({ message: 'Category not found.' });
		}

		res.send(category);
	} catch (error) {
		res.status(500).json({ message: error.message });
	}
});

module.exports = router;
