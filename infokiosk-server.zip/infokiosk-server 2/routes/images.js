const express = require('express');
const multer = require('multer');

const router = express.Router();

const broadcastMessage = require('../helpers/websocket');

const storage = multer.diskStorage({
	destination: function (req, file, cb) {
		cb(null, 'uploads/');
	},
	filename: function (req, file, cb) {
		const originalname = file.originalname;
		const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
		const extension = originalname.split('.').pop();
		cb(null, originalname + '-' + uniqueSuffix + '.' + extension); // Unique filename
	},
});

const upload = multer({
	storage: storage,
	limits: {
		fileSize: 20 * 1024 * 1024, // 20MB limit dla pojedynczego pliku
		fieldSize: 100 * 1024 * 1024, // Zwiększono limit na wielkość pola do 100MB
	},
	fileFilter: (req, file, cb) => {
		if (file.mimetype === 'image/jpeg' || file.mimetype === 'image/png') {
			cb(null, true);
		} else {
			cb(new Error('Niedozwolony format pliku. Dozwolone formaty: JPEG i PNG'));
		}
	},
});

router.post('/upload', upload.single('file'), (req, res) => {
	if (!req.file) {
		return res.status(400).json({ message: 'Nie przesłano pliku' });
	}

	const filePath = req.file.path;
	// Zwróć ścieżkę przesłanego pliku w odpowiedzi
	res.status(200).json({ message: 'Plik został pomyślnie przesłany', filePath: filePath });
});

module.exports = router;
