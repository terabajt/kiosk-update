const express = require('express');
const { Settings } = require('../models/settings');
const multer = require('multer');
const { default: mongoose } = require('mongoose');

const router = express.Router();

const storage = multer.diskStorage({
	destination: function (req, file, cb) {
		cb(null, 'uploads/');
	},
	filename: function (req, file, cb) {
		const originalname = file.originalname;
		const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
		const extension = originalname.split('.').pop();
		cb(null, originalname + '-' + uniqueSuffix + '.' + extension); // Unique filename
	},
});

const upload = multer({
	storage: storage,
	limits: {
		fileSize: 20 * 1024 * 1024, // 20MB limit dla pojedynczego pliku
		fieldSize: 100 * 1024 * 1024, // Zwiększono limit na wielkość pola do 100MB
	},
	fileFilter: (req, file, cb) => {
		if (file.mimetype === 'image/jpeg' || file.mimetype === 'image/png') {
			cb(null, true);
		} else {
			cb(new Error('Niedozwolony format pliku. Dozwolone formaty: JPEG i PNG'));
		}
	},
});

router.get('/', async (req, res) => {
	try {
		const settings = await Settings.findOne();
		res.send(settings);
	} catch (error) {
		console.error(error);
		res.status(500).json({ message: 'Server Error' });
	}
});

router.post('/', upload.single('logo'), async (req, res) => {
	try {
		const {
			contact_info_pl,
			contact_info_en,
			contact_info_ua,
			oncall_info_pl,
			oncall_info_en,
			oncall_info_ua,
			footer_info_pl,
			footer_info_en,
			footer_info_ua,
			hello_text_pl,
			hello_text_en,
			hello_text_ua,
			floating_text_pl,
			floating_text_en,
			floating_text_ua,
		} = req.body;
		const logo = req.file ? req.file.filename : ''; // Jeśli istnieje plik, pobierz jego nazwę

		const settings = new Settings({
			contact_info_pl,
			contact_info_en,
			contact_info_ua,
			oncall_info_pl,
			oncall_info_en,
			oncall_info_ua,
			footer_info_pl,
			footer_info_en,
			footer_info_ua,
			hello_text_pl,
			hello_text_en,
			hello_text_ua,
			floating_text_pl,
			floating_text_en,
			floating_text_ua,
			logo,
		});

		const savedSettings = await settings.save();
		res.status(201).json(savedSettings);
	} catch (error) {
		console.error(error);
		res.status(500).json({ message: 'Server Error, can not save settings' });
	}
});

router.put('/:id', upload.single('logo'), async (req, res) => {
	try {
		const { id } = req.params;
		const settings = await Settings.findById(id);
		if (!settings) {
			return res.status(404).json({ message: 'Settings not found' });
		}

		settings.contact_info_pl = req.body.contact_info_pl;
		settings.contact_info_en = req.body.contact_info_en;
		settings.contact_info_ua = req.body.contact_info_ua;
		settings.oncall_info_pl = req.body.oncall_info_pl;
		settings.oncall_info_en = req.body.oncall_info_en;
		settings.oncall_info_ua = req.body.oncall_info_ua;
		settings.footer_info_pl = req.body.footer_info_pl;
		settings.footer_info_en = req.body.footer_info_en;
		settings.footer_info_ua = req.body.footer_info_ua;
		settings.hello_text_pl = req.body.hello_text_pl;
		settings.hello_text_en = req.body.hello_text_en;
		settings.hello_text_ua = req.body.hello_text_ua;
		settings.floating_text_pl = req.body.floating_text_pl;
		settings.floating_text_en = req.body.floating_text_en;
		settings.floating_text_ua = req.body.floating_text_ua;

		// Jeśli przesłano nowe logo, zaktualizuj nazwę
		if (req.file) {
			settings.logo = req.file.filename;
		}

		const updatedSettings = await settings.save();
		res.status(200).json(updatedSettings);
	} catch (error) {
		console.error(error);
		res.status(500).json({ message: 'Server Error, can not save settings' });
	}
});

module.exports = router;
