const express = require('express');
const { User } = require('../models/user');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const mongoose = require('mongoose');
const uuid = require('uuid');
const { History } = require('../models/history');


//Register
router.post('/register', async (req, res) => {
	try {
		const existingUser = await User.findOne({ email: req.body.email });
		if (existingUser) {
			return res.status(400).send('Użytkownik istnieje w bazie.');
		}
		const activationToken = uuid.v4();
		const user = new User({
			email: req.body.email,
			name: req.body.email,
			passwordHash: bcrypt.hashSync(req.body.password, 10),
			activationToken,
		});
		const savedUser = await user.save();

		if (!savedUser) {
			return res.status(400).send('The user cannot be created.');
		}
		return res.status(200).send('Poprawnie dodano użytkownika.');
	} catch (error) {
		console.error(error);
		res.status(500).send('Internal Server Error');
	}
});

router.post('/change-password', async (req, res) => {
	const { userId, currentPassword, newPassword } = req.body;
	try {
		const user = await User.findOne({ _id: userId });
		if (!user) {
			return res.status(404).send('User not found');
		}

		const isMatch = await bcrypt.compare(currentPassword, user.passwordHash);
		if (!isMatch) {
			return res.status(400).send('Podałeś niepoprawne obecne hasło.');
		}

		const newPasswordHash = await bcrypt.hash(newPassword, 10);
		user.passwordHash = newPasswordHash;
		await user.save();

		res.status(200).send('Hasło zmieniono pomyślnie.');
	} catch (error) {
		console.error(error);
		res.status(500).send('Internal Server Error');
	}
});
router.post('/change-password-user/', async (req, res) => {
	const { userId, newPassword } = req.body;
	try {
		const user = await User.findOne({ _id: userId });
		if (!user) {
			return res.status(404).send('User not found');
		}
		const newPasswordHash = await bcrypt.hash(newPassword, 10);
		user.passwordHash = newPasswordHash;
		await user.save();
		res.status(200).send('Hasło zmieniono pomyślnie.');
	} catch (error) {
		console.error(error);
		res.status(500).send('Internal Server Error');
	}
});


router.post('/login', async (req, res) => {
	const { email, password } = req.body;
	try {
		const user = await User.findOne({ email });
		if (!user) {
			return res.status(404).send('The user not found! Please check user credentials');
		}
		if (user && bcrypt.compareSync(password, user.passwordHash)) {
			const token = jwt.sign(
				{
					userId: user.id,
					isAdmin: user.isAdmin,
				},
				process.env.SECRET,
				{ expiresIn: '1d' }
			);
			res.status(200).json({ token });
		} else {
			return res.status(404).send('Password is wrong');
		}
	} catch (error) {
		console.error(error);
		return res.status(500).send('Internal Server Error');
	}
});

router.get('/user/:id', async (req, res) => {
	try {
		const userId = req.params.id;
		const user = await User.findById(userId);
		if (!user) {
			return res.status(404).send('User not found');
		}
		res.status(200).json(user);
	} catch (error) {
		console.error(error);
		res.status(500).send('Internal Server Error');
	}
});

router.get('/users/', async (req, res) => {
	try {
		const users = await User.find();
		res.status(200).json(users);
	} catch (error) {
		console.error(error);
		res.status(500).send('Internal Server Error');
	}
});

router.delete('/user/:id', async (req, res) => {
	const userId = req.params.id;
	try {
		const user = await User.findByIdAndDelete(userId);
		if (!user) {
			return res.status(404).send('Użytkownik nie znaleziony');
		}
		res.status(200).send('Użytkownik usunięty pomyślnie.');
	} catch (error) {
		console.error(error);
		res.status(500).send('Internal Server Error');
	}
});
router.put('/user/:id', async (req, res) => {
	const userId = req.params.id;
	const updates = req.body;
	console.log(updates);

	try {
		const user = await User.findByIdAndUpdate(userId, updates, { new: true });
		if (!user) {
			return res.status(404).send('Użytkownik nie znaleziony');
		}
		res.status(200).send('Użytkownik zaktualizowany poprawnie');
	} catch (error) {
		console.error(error);
		res.status(500).send('Internal Server Error');
	}
});



router.get('/logs', async (req, res) => {
	try {
		const logs = await History.find()
			.populate('infoId')
			.populate('editedBy');
		res.status(200).json(logs);
	} catch (error) {
		console.error(error);
		res.status(500).send('Internal Server Error');
	}
});

module.exports = router;
