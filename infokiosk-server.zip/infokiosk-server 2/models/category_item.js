const mongoose = require('mongoose');

const categoryItemSchema = mongoose.Schema({
	label_pl: {
		type: String,
		required: true,
	},
	label_en: {
		type: String,
		default: '',
	},
	label_ua: {
		type: String,
		default: '',
	},
	icon: {
		type: String,
		default: 'info',
	},
	routerLink: {
		type: String,
		require: true,
	},
	display: {
		type: Boolean,
		default: true,
	},
	infoId: {
		type: mongoose.Schema.Types.ObjectId,
		ref: 'Info',
		required: true,
	},
});

categoryItemSchema.virtual('id').get(function () {
	return this._id.toHexString();
});

categoryItemSchema.set('toJSON', {
	virtuals: true,
});

exports.CategoryItem = mongoose.model('CategoryItem', categoryItemSchema);
