const mongoose = require('mongoose');

const historySchema = mongoose.Schema({
	infoId: {
		type: mongoose.Schema.Types.ObjectId,
		ref: 'Info',
		required: true,
	},
	editedBy: {
		type: mongoose.Schema.Types.ObjectId,
		ref: 'User',
		required: true,
	},
	editedAt: {
		type: Date,
		default: Date.now,
	},
});

exports.History = mongoose.model('History', historySchema);
