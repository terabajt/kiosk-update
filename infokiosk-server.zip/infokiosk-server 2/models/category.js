const mongoose = require('mongoose');

const categorySchema = mongoose.Schema({
	label_pl: {
		type: String,
		required: true,
	},
	label_en: {
		type: String,
		default: '',
	},
	label_ua: {
		type: String,
		default: '',
	},
	icon: {
		type: String,
		default: 'info',
	},
	routerLink: {
		type: String,
		require: true,
	},
	display: {
		type: Boolean,
		default: true,
	},
});

categorySchema.virtual('id').get(function () {
	return this._id.toHexString();
});

categorySchema.set('toJSON', {
	virtuals: true,
});

exports.Category = mongoose.model('Category', categorySchema);
