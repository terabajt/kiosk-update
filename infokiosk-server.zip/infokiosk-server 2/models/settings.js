const mongoose = require('mongoose');

const settingsSchema = mongoose.Schema({
	contact_info_pl: {
		type: String,
		default: 'contact',
	},
	contact_info_en: {
		type: String,
		default: 'contact',
	},
	contact_info_ua: {
		type: String,
		default: 'contact',
	},
	oncall_info_pl: {
		type: String,
		default: 'on call',
	},
	oncall_info_en: {
		type: String,
		default: 'on call',
	},
	oncall_info_ua: {
		type: String,
		default: 'on call',
	},
	footer_info_pl: {
		type: String,
		default: 'footer',
	},
	footer_info_en: {
		type: String,
		default: 'footer',
	},
	footer_info_ua: {
		type: String,
		default: 'footer',
	},
	hello_text_pl: {
		type: String,
		default: 'Welcome',
	},
	hello_text_en: {
		type: String,
		default: 'Welcome',
	},
	hello_text_ua: {
		type: String,
		default: 'Welcome',
	},
	floating_text_pl: {
		type: String,
		default: 'Floating text',
	},
	floating_text_en: {
		type: String,
		default: 'Floating text',
	},
	floating_text_ua: {
		type: String,
		default: 'Floating text',
	},
	logo: { type: String, default: 'logo.png' },
});

settingsSchema.virtual('id').get(function () {
	return this._id.toHexString();
});

settingsSchema.set('toJSON', {
	virtuals: true,
});

exports.Settings = mongoose.model('Settings', settingsSchema);
