const mongoose = require('mongoose');

const timetableSchema = mongoose.Schema({
	grade: {
		type: String,
		required: true,
	},
	text_pl: {
		type: String,
		required: true,
	},
	text_en: {
		type: String,
		default: 'Please add content',
	},
	text_ua: {
		type: String,
		default: 'Please add content',
	},
	comments: {
		type: String,
		default: '',
	},
	display: {
		type: Boolean,
		default: true,
	},
});

timetableSchema.virtual('id').get(function () {
	return this._id.toHexString();
});

timetableSchema.set('toJSON', {
	virtuals: true,
});

exports.Timetable = mongoose.model('Timetable', timetableSchema);
