const mongoose = require('mongoose');

const infoSchema = mongoose.Schema({
	name: {
		type: String,
		required: true,
	},
	title_pl: {
		type: String,
		required: true,
	},
	title_ua: {
		type: String,
		default: 'Please add content',
	},
	title_en: {
		type: String,
		default: 'Please add content',
	},
	text_pl: {
		type: String,
		required: true,
	},
	text_en: {
		type: String,
		default: 'Please add content',
	},
	text_ua: {
		type: String,
		default: 'Please add content',
	},
	category: {
		type: mongoose.Schema.Types.ObjectId,
		ref: 'Category',
		require: true,
	},
	images: [{ type: String }],
	date: {
		type: Date,
		default: Date.now,
	},
	date_to_display: {
		type: Date,
	},
	display: {
		type: Boolean,
		default: true,
	},
	image: {
		type: String,
		default: 'news',
	},
	history: [
		{
			type: mongoose.Schema.Types.ObjectId,
			ref: 'History',
		},
	],
});

infoSchema.virtual('id').get(function () {
	return this._id.toHexString();
});

infoSchema.set('toJSON', {
	virtuals: true,
});

exports.Info = mongoose.model('Info', infoSchema);
